import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/prof/ajouter_prof.dart';
import 'package:flutter_auth/Screens/prof/profile_prof.dart';
import 'package:flutter_auth/Widgets/AppBar.dart';
import 'package:flutter_auth/Widgets/Exams/SubjectCard.dart';
import 'package:http/http.dart' as http;

import '../../constants.dart';
import 'ajouter_exam.dart';

class ListeExam extends StatefulWidget {
  ListeExam({Key key}) : super(key: key);

  @override
  _ListeExamState createState() => _ListeExamState();
}

class _ListeExamState extends State<ListeExam>
    with SingleTickerProviderStateMixin {
  Animation animation, delayedAnimation, muchDelayedAnimation, LeftCurve;
  AnimationController animationController;
  String nom;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //SystemChrome.setEnabledSystemUIOverlays([]);

    animationController =
        AnimationController(duration: Duration(seconds: 3), vsync: this);
    animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController, curve: Curves.fastOutSlowIn));

    delayedAnimation = Tween(begin: 1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.2, 0.5, curve: Curves.fastOutSlowIn)));

    muchDelayedAnimation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.3, 0.5, curve: Curves.fastOutSlowIn)));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    animationController.dispose();
    super.dispose();
  }

  List<dynamic> lst = [];
  Future<List<dynamic>> getData() async {
    Map<String, String> headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
    'authorization': 'Basic c3R1ZHlkb3RlOnN0dWR5ZG90ZTEyMw=='
  };
    var url = "https://alcachy.000webhostapp.com/API/liste_classes.php";
    var responsive = await http.get(Uri.parse(url), headers: headers);
    var res = json.decode(responsive.body);

    lst = res as List<dynamic>;
    return lst;
  }

  @override
  Widget build(BuildContext context) {
    animationController.forward();
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;
    return AnimatedBuilder(
        animation: animationController,
        builder: (BuildContext context, Widget child) {
          final GlobalKey<ScaffoldState> _scaffoldKey =
              new GlobalKey<ScaffoldState>();
          return Scaffold(
              floatingActionButton: FloatingActionButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => Ajouter_exam(),
                  ));
                },
                child: const Icon(Icons.add),
                backgroundColor: kPrimaryColor,
              ),
              key: _scaffoldKey,
              appBar: CommonAppBar(
                exitAble: false,
                homeAble: true,
                title: "Examens",
                ontap: () {
                  _scaffoldKey.currentState.openDrawer();
                },
              ),

              // liste des professeurs
              body: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 5,
                    horizontal: 15,
                  ),
                  child: Column(
                    children: [
                      GestureDetector(
                          onTap: () {},
                          child: FutureBuilder<List<dynamic>>(
                            future: getData(),
                            builder: (BuildContext context,
                                AsyncSnapshot<List<dynamic>> snapshot) {
                              return Column(children: [
                                for (Map prof in lst)
                                  Transform(
                                    transform: Matrix4.translationValues(
                                        muchDelayedAnimation.value * width,
                                        0,
                                        0),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width,
                                      height: 50,
                                      margin: const EdgeInsets.only(top: 8.0),
                                      child: SubjectCard(
                                        visible: 'prof',
                                        subjectname:
                                            prof['libelle_classe'].toString(),
                                      ),
                                    ),
                                  )
                              ]
                                  // Container(
                                  //                 child: Center(
                                  //                     child: Text(
                                  //                         lst[index]['nom'].toString())));

                                  );
                              Column();
                            },
                          )),
                      // Transform(
                      //   transform: Matrix4.translationValues(
                      //       muchDelayedAnimation.value * width, 0, 0),
                      //   child: Padding(
                      //     padding: const EdgeInsets.only(top: 8.0),
                      //     child: SubjectCard(
                      //       subjectname: "Professeur 2",
                      //     ),
                      //   ),
                      // ),
                      // Transform(
                      //   transform: Matrix4.translationValues(
                      //       muchDelayedAnimation.value * width, 0, 0),
                      //   child: Padding(
                      //     padding: const EdgeInsets.only(top: 8.0),
                      //     child: SubjectCard(
                      //       subjectname: "Professeur 3",
                      //     ),
                      //   ),
                      // ),
                      // Transform(
                      //   transform: Matrix4.translationValues(
                      //       muchDelayedAnimation.value * width, 0, 0),
                      //   child: Padding(
                      //     padding: const EdgeInsets.only(top: 8.0),
                      //     child: SubjectCard(
                      //       subjectname: "Professeur 4",
                      //     ),
                      //   ),
                      // ),
                      // Transform(
                      //   transform: Matrix4.translationValues(
                      //       muchDelayedAnimation.value * width, 0, 0),
                      //   child: Container(
                      //     height: 80,
                      //     padding: const EdgeInsets.only(top: 8.0),
                      //     child: SubjectCard(
                      //       subjectname: "Professeur 5",
                      //     ),
                      //   ),
                      // ),
                      SizedBox(
                        height: height * 0.05,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(),
                          SizedBox(
                            width: 5,
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 13.0),
                        child: Row(),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 18, 0, 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Transform(
                              transform: Matrix4.translationValues(
                                  muchDelayedAnimation.value * width, 0, 0),
                            ),
                            Transform(
                              transform: Matrix4.translationValues(
                                  delayedAnimation.value * width, 0, 0),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: height * 0.20,
                      ),
                    ],
                  ),
                ),
              ));
        });
  }
}
