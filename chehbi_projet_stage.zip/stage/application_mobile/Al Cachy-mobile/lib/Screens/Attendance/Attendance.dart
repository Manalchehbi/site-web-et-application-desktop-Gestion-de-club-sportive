import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Attendance/OverallAttendance.dart';
import 'package:flutter_auth/Screens/Attendance/TodayAttendance.dart';
import 'package:flutter_auth/Screens/home.dart';
import 'package:flutter_auth/Widgets/AppBar.dart';

import 'package:flutter_auth/Widgets/UserDetailCard.dart';

class Attendance extends StatefulWidget {
  @override
  _AttendanceState createState() => _AttendanceState();
}

class _AttendanceState extends State<Attendance>
    with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _scaffoldKey =
        new GlobalKey<ScaffoldState>();
    return Scaffold(
      key: _scaffoldKey,
      appBar: CommonAppBar(
        title: "Mes Notes",
        homeAble: true,
        exitAble: false,
        ontap: () {
          _scaffoldKey.currentState.openDrawer();
        },
      ),
      body: DefaultTabController(
        length: 2, // length of tabs
        initialIndex: 0,
        child: Column(
          children: <Widget>[
            Container(
              child: TabBar(
                labelColor: Colors.black,
                unselectedLabelColor: Colors.black26,
                indicatorColor: Colors.black,
                tabs: [
                  Tab(text: '1ère Semistre'),
                  Tab(text: '2ème Semistre'),
                ],
              ),
            ),
            Expanded(
              child: Container(
                //height of TabBarView
                padding: EdgeInsets.symmetric(
                  horizontal: 10,
                ),
                child: TabBarView(
                  children: <Widget>[
                    TodayAttendance(),
                    OverallAttendance(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
