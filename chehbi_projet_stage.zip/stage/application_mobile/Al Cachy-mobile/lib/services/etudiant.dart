class Etudiant {
  int idUser;
  String login;
  String motPasse;
  String type;
  String nom;
  String prenom;
  String dateNaiss;
  String lieuNaiss;
  String telephone;
  String adresse;
  String ville;
  String email;

  Etudiant(
      {this.idUser,
      this.login,
      this.motPasse,
      this.type,
      this.nom,
      this.prenom,
      this.dateNaiss,
      this.lieuNaiss,
      this.telephone,
      this.adresse,
      this.ville,
      this.email});

  factory Etudiant.fromJson(Map<String, dynamic> json) {
    return Etudiant(
      idUser: json['id_user'] as int,
      login: json['login'] as String,
      motPasse: json['mot_passe'] as String,
      type: json['type'] as String,
      nom: json['nom'] as String,
      prenom: json['prenom'] as String,
      dateNaiss: json['date_naissance'] as String,
      lieuNaiss: json['lieu_naissance'] as String,
      telephone: json['telephone'] as String,
      adresse: json['adresse'] as String,
      ville: json['ville'] as String,
      email: json['email'] as String,
    );
  }
}
