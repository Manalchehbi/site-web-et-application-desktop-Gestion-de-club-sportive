<footer class="footer bg-light">
	<div class="container-fluid text-center">
		<div class="row">
			<div  class="col-sm-4">
				<div class="copyright">Tous les droits sont réservés | &copy; <?php echo SITE_NAME ?> - <?php echo date('Y') ?></div>
			</div>
		
		</div>
	</div>
</footer>
