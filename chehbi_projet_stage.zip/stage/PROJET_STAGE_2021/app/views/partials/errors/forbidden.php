
<div class="container">
	<div class="row justify-content-center">
		<div class="col-sm-8">
			<div style="margin:8% 0" class="card card-body">
				<div class="text-center">
					<h2 class="text-danger mb-2">Resource Access  Forbidden</h2>
					<div class="text-muted"><small>Please Contact The System Administrator For More Information</small></div>
				</div>
			</div>
		</div>
	</div>
</div>