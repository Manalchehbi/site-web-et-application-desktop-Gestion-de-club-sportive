import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/etudiant/profile_etudiant.dart';
import 'package:flutter_auth/Screens/prof/profile_prof.dart';
import 'package:flutter_auth/constants.dart';

class SubjectCard extends StatelessWidget {
  final String subjectname;
  final String visible;

  SubjectCard({
    Key key,
    this.subjectname,
    this.visible,
  });
  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(7),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: kPrimaryColor.withOpacity(0.4),
              blurRadius: 2,
              offset: Offset(0, 2),
              spreadRadius: 1,
            ),
          ]),
      padding: EdgeInsets.all(7),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "${subjectname}",
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: kPrimaryColor),
          ),
          Row(
            children: [
              IconButton(
                  icon: Icon(Icons.visibility),
                  color: blueMaftouh,
                  onPressed: () {
                    if (visible == 'etudiant') {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => Profile_etudiant(),
                      ));
                    } else if (visible == 'prof') {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => Profile_prof(),
                      ));
                    } else if (visible == 'classe') {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => Profile_prof(),
                      ));
                    }
                  }),
            ],
          )
        ],
      ),
    );
  }
}
