import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_auth/Widgets/AppBar.dart';
import 'package:flutter_auth/constants.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;

class Ajouter_exam extends StatefulWidget {
  @override
  _Ajouter_examState createState() => _Ajouter_examState();
}

DateTime selectedDate = DateTime.now();
TextEditingController _dateController = TextEditingController();

// Getting value from TextField widget.

class _Ajouter_examState extends State<Ajouter_exam> {
  bool visible = false;
  String valueChoose;
  List listeClas = [
    'classe',
    'classe 1',
    'classe 2',
    'classe 3',
    'classe 4',
    'classe 5',
    'classe 6',
  ];
  final libelleExamController = TextEditingController();
  final classeController = TextEditingController();
  final matiereController = TextEditingController();
  final salleController = TextEditingController();
  final dateController = TextEditingController();
  final heurdController = TextEditingController();
  final dureeController = TextEditingController();

  Future<List<dynamic>> enregistrement() async {
    String libelle = libelleExamController.text;
    String classe = classeController.text;
    String matiere = matiereController.text;
    String salle = salleController.text;
    String date = dateController.text;
    String heur = heurdController.text;
    String duree = dureeController.text;
    setState(() {
      visible = true;
    });
    Map<String, String> headers = {
      'Content-Type': 'applicaton/json',
      'Charset': 'utf-8'
    };
    var url = "https://alcachy.000webhostapp.com/API/liste_classes.php" as Uri;
    var data = {
      'libelle': libelle,
      'matiere': matiere,
      'heur': heur,
      'date': date,
      'classe': classe,
      'salle': salle,
      'duree': duree
    };
    var response = await http.post(url, body: data, headers: headers);

    // Getting Server response into variable.
    var message = jsonDecode(response.body);
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text(message),
          actions: <Widget>[
            FlatButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  bool showPassword = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(
        homeAble: true,
        exitAble: false,
        title: "Ajouter des examens  ",
        ontap: () {},
      ),
      body: Container(
        padding: EdgeInsets.only(left: 16, top: 25, right: 16),
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: ListView(
            children: [
              buildTextField("libillé d'examen  ", "", false, false,
                  libelleExamController),
              DropdownButton(
                hint: Text("la classe "),
                value: valueChoose,
                dropdownColor: Colors.white,
                onChanged: (newValue) {
                  setState(() {
                    valueChoose = newValue;
                  });
                },
                items: listeClas.map((valueItem) {
                  return DropdownMenuItem(
                    value: valueItem.toString(),
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              DropdownButton(
                hint: Text(" la matiere "),
                value: valueChoose,
                dropdownColor: Colors.white,
                onChanged: (newValue) {
                  setState(() {
                    valueChoose = newValue;
                  });
                },
                items: listeClas.map((valueItem) {
                  return DropdownMenuItem(
                    value: valueItem.toString(),
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              DropdownButton(
                hint: Text("selectionner la salle "),
                value: valueChoose,
                dropdownColor: Colors.white,
                onChanged: (newValue) {
                  setState(() {
                    valueChoose = newValue;
                  });
                },
                items: listeClas.map((valueItem) {
                  return DropdownMenuItem(
                    value: valueItem.toString(),
                    child: Text(valueItem),
                  );
                }).toList(),
              ),
              Text("Date"),
              SizedBox(
                height: 2,
              ),
              TextFormField(
                controller: _dateController,
                decoration: InputDecoration(
                    suffixIcon: IconButton(
                        color: kPrimaryColor,
                        icon: Icon(Icons.date_range_outlined),
                        onPressed: () => _selectDate(context))),
              ),
              SizedBox(
                height: 30,
              ),
              buildTextField(
                  "Heur ", "", false, false, dateController),
              buildTextField(
                  "Durée", "", false, false, dureeController),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  OutlineButton(
                    padding: EdgeInsets.symmetric(horizontal: 5),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    disabledBorderColor: Colors.red,
                    onPressed: () {},
                  ),
                  RaisedButton(
                    onPressed: () {
                      
                      enregistrement();
                    },
                    color: Colors.purple,
                    padding: EdgeInsets.symmetric(horizontal: 50),
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20)),
                    child: Text(
                      "VALIDER",
                      style: TextStyle(
                          fontSize: 13,
                          letterSpacing: 2.2,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTextField(
      String labelText,
      String placeholder,
      bool isPasswordTextField,
      bool modifie,
      TextEditingController valeurText) {
    return Padding(
        padding: const EdgeInsets.only(bottom: 35.0),
        child: TextField(
          controller: valeurText,
          obscureText: isPasswordTextField ? showPassword : false,
          decoration: InputDecoration(
           
            suffixIcon: isPasswordTextField
                ? IconButton(
                    onPressed: () {
                      setState(() {
                        showPassword = !showPassword;
                      });
                    },
                    icon: Icon(
                      Icons.remove_red_eye,
                      color: kPrimaryColor,
                    ),
                  )
                : null,
            contentPadding: EdgeInsets.only(bottom: 3),
            labelText: labelText,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            hintText: placeholder,
            hintStyle: modifie == false
                ? TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                  )
                : TextStyle(
                    fontSize: 16,
                    color: Colors.black,
                  ),
          ),
        ));
  }

  Future<Null> _selectDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(2015),
        lastDate: DateTime(2101));
    if (picked != null)
      setState(() {
        selectedDate = picked;
        _dateController.text = DateFormat.yMd().format(selectedDate);
      });
  }
}
