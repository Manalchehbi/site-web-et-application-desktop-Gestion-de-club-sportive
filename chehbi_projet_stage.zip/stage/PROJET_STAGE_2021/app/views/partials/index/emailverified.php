<div class="container">
	<h4>[html-lang-0114]</h4>
	<hr />
	<div class="card">
		<a href="<?php print_link('index') ?>" class="btn btn-primary">[html-lang-0115]</a>
	</div>
</div>



