<div class="container">
	<h3>Gestionnaire de réinitialisation de mot de passe</h3>
	<hr />
	<div>
		<h4 class="text-success">
			<i class="fa fa-envelope"></i> Un message a été envoyé à votre email. Veuillez suivre le lien pour réinitialiser votre mot de passe 
		</h4>
	</div>
</div>
