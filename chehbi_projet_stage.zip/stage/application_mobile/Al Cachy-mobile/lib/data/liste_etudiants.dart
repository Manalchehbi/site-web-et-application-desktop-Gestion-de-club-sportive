import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'flutter dimo',
      theme: ThemeData(visualDensity: VisualDensity.adaptivePlatformDensity),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var lst = [];
  Future<List<dynamic>> getData() async {
    Map<String, String> headers = {
      'Content-Type': 'applicaton/json',
      'Charset': 'utf-8'
    };
    var url = "https://alcachy.000webhostapp.com/API/liste_etudiants.php";
    var responsive = await http.get(Uri.parse(url), headers: headers);
    var res = json.decode(responsive.body);
    lst = res as List<dynamic>;
    return lst;
  }

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
        body: FutureBuilder(
          future: getData(),
          builder:
              (BuildContext context, AsyncSnapshot<List<dynamic>> snapshot) {
            return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (context, index) {
                return Container(

                    margin: EdgeInsets.only(bottom: 2),
                    child: Center(child: Text(lst[index]['nom'].toString())));
              },
            );
          },
        ));
  }
}
