<div class="container">
	<h3>Gestionnaire de réinitialisation de mot de passe</h3>
	
	<div class="card card-body mt-4 animated bounce">
		<h3 class="text-danger bold">Votre réinitialisation du mot de passe n'est pas terminée</h3>
		<div class="text-muted">Echec de la réinitialisation du mot de passe</div>
		<hr />
		<div class="text-success">
			S'il vous plaît vous pouvez essayer de réinitialiser votre mot de passe en suivant ces étapes
			<br />
			<br />
			<a href="<?php print_link("passwordmanager/") ?>" class="btn btn-primary">réinitialiser le mot de passe</a>
		</div>
	</div>
</div>
