<div class="container">
	<h4>Help And Frequently Asked Questions</h4>
	<hr />
	<div>
		Put page content here
	</div>
	<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/contact.php</i></small>
</div>