import 'package:flutter/foundation.dart';

class Prof {
  int id;
  String nom;
  String prenom;
  Prof({this.id, this.nom, this.prenom});
  factory Prof.fromJson(Map<String, dynamic> json) {
    return Prof(
      id: json['id_user'] as int,
      nom:json['nom'] as String,
      prenom: json['prenom'] as String,
    );
  }
}
