import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_prj/login/login.dart';

// ignore: must_be_immutable
class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SplashScreenState();
  }
}

class SplashScreenState extends State<SplashScreen> {
  SplashScreenState();

  @override
  void initState() {
    super.initState();

    Timer(Duration(seconds: 3), () {
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (context) {
        return LoginPage();
      }));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.cyan[500],
      width: double.infinity,
      height: double.infinity,
    );
  }
}
