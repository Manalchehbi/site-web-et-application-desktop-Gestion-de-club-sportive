import 'package:flutter/material.dart';

class MyProvider with ChangeNotifier {
  var activeUser = [];
  setactiveUser(lst) {
    activeUser = lst;
    notifyListeners();
  }
}
