import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/home.dart';
import 'package:flutter_auth/Screens/home_Prof.dart';
import 'package:flutter_auth/constants.dart';

class CommonAppBar extends StatelessWidget with PreferredSizeWidget {
  final String title;
  final bool exitAble;
  final bool homeAble;
  final String typeHome;
  final Function ontap;
  const CommonAppBar({
    Key key,
    this.title,
    this.exitAble,
    this.homeAble,
    this.ontap,
    this.typeHome,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (exitAble == false) {
      return AppBar(
        title: Text(
          "${title}",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.purple,
        actions: [
          homeAble == true
              ? InkWell(
                  onTap: () {},
                  child: IconButton(
                    color: Colors.white,
                    onPressed: ontap,
                    icon: Icon(
                      Icons.home,
                      color: Colors.white,
                    ),
                  ))
              : SizedBox(
                  width: 1,
                ),
        ],
        centerTitle: true,
        elevation: 0.0,
      );
    }
    return AppBar(
      title: Text(
        "${title}",
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      leading: IconButton(
        color: Colors.black,
        onPressed: () => exit(0),
        icon: Icon(
          Icons.exit_to_app,
          color: Colors.white,
        ),
      ),
      actions: [
        homeAble == true
            ? InkWell(
                onTap: () {
                  if (typeHome == 'etudiant') {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => HomeEtudiant(),
                    ));
                  } else if (typeHome == 'admin') {
                    Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => Home_Prof(),
                    ));
                  }
                },
                child: IconButton(
                  color: Colors.white,
                  onPressed: ontap,
                  icon: Icon(
                    Icons.home,
                    color: Colors.white,
                  ),
                ))
            : SizedBox(
                width: 1,
              ),
      ],
      centerTitle: true,
      backgroundColor: blueMaftouh,
      elevation: 0.0,
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size.fromHeight(50);
}
