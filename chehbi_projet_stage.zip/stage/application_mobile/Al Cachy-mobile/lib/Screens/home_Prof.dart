import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_auth/Screens/Attendance/Classe.dart';

import 'package:flutter_auth/Screens/absence.dart';
import 'package:flutter_auth/Screens/prof/liste_classe.dart';

import 'package:flutter_auth/Widgets/AppBar.dart';
import 'package:flutter_auth/Widgets/BouncingButton.dart';
import 'package:flutter_auth/Widgets/DashboardCards.dart';

import 'package:flutter_auth/Widgets/UserDetailCard.dart';

import 'Exam/liste_exam.dart';

class Home_Prof extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home_Prof> with SingleTickerProviderStateMixin {
  Animation animation, delayedAnimation, muchDelayedAnimation;
  AnimationController animationController;

  @override
  void initState() {
    super.initState();

    SystemChrome.setEnabledSystemUIOverlays([]);
    animationController =
        AnimationController(duration: Duration(seconds: 3), vsync: this);
    animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController, curve: Curves.fastOutSlowIn));

    delayedAnimation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.5, 1.0, curve: Curves.fastOutSlowIn)));

    muchDelayedAnimation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.8, 1.0, curve: Curves.fastOutSlowIn)));
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // GetData data = GetData();

    print("xdgdxc");

    final double width = MediaQuery.of(context).size.width;

    animationController.forward();

    return AnimatedBuilder(
      animation: animationController,
      builder: (BuildContext context, Widget child) {
        final GlobalKey<ScaffoldState> _scaffoldKey =
            new GlobalKey<ScaffoldState>();
        return Scaffold(
          key: _scaffoldKey,
          appBar: CommonAppBar(
            homeAble: false,
            exitAble: true,
            title: "Espace de professeur",
          ),
          body: ListView(
            children: [
              UserDetailCard(),
              SizedBox(
                height: 10,
              ),
              Container(
                alignment: Alignment(1.0, 0),
                child: Padding(
                  padding: const EdgeInsets.only(top: 10.0, right: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Transform(
                        transform: Matrix4.translationValues(
                            muchDelayedAnimation.value * width, 0, 0),
                        child: Bouncing(
                          onPress: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      ListeExam(),
                                ));
                          },
                          child: DashboardCard(
                            name: "Examens",
                            imgpath: "controle.svg",
                          ),
                        ),
                      ),
                      Transform(
                        transform: Matrix4.translationValues(
                            delayedAnimation.value * width, 0, 0),
                        child: Bouncing(
                          onPress: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      ListeClasse(),
                                ));
                          },
                          child: DashboardCard(
                            name: "Classes",
                            imgpath: "profilee.svg",
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                alignment: Alignment(1.0, 0),
                width: width,
                child: Padding(
                  padding: const EdgeInsets.only(top: 10.0, right: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Transform(
                        transform: Matrix4.translationValues(
                            muchDelayedAnimation.value * width, 0, 0),
                        child: Bouncing(
                          onPress: () {},
                          child: DashboardCard(
                            name: "chat",
                            imgpath: "chat3.svg",
                          ),
                        ),
                      ),
                      Transform(
                        transform: Matrix4.translationValues(
                            delayedAnimation.value * width, 0, 0),
                        child: Bouncing(
                          onPress: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) => Absence(),
                                ));
                          },
                          child: DashboardCard(
                            name: "emploi du temps",
                            imgpath: "date.svg",
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
            ],
          ),
        );
      },
    );
  }
}
