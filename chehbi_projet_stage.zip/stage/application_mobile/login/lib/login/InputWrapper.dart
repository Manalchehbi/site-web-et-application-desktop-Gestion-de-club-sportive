import 'package:flutter/material.dart';
import 'package:flutter_prj/provider.dart';
import 'package:provider/provider.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';

import 'Button.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/top_snack_bar.dart';

// ignore: must_be_immutable
class InputWrapper extends StatelessWidget {
  MyProvider provider;
  var email = "";
  var pw = "";
  var emE;
  var pwE;

  BuildContext ctxt;
  setStatus(var msg) async{
    print(msg);
    if ((msg.toString()).trim() == 'email existe pas' ||
        (msg.toString()).trim() == 'password incorrecte') {
      showTopSnackBar(
        ctxt,
        CustomSnackBar.error(
          message: msg.toString().trim(),
        ),
      );
    } else{
      print(msg);

      provider.setactiveUser(msg);//khatae
    }
  }

  login() async {
    print("Login");
    Map<String, String> headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'authorization': 'Basic c3R1ZHlkb3RlOnN0dWR5ZG90ZTEyMw=='
    };
    // ignore: unused_local_variable
    final response = await http.post(
        Uri.parse("https://alcachy.000webhostapp.com/API/login.php"),
        headers: headers,
        body: {
          "email": email,
          "pw": pw,
        }).then((result) {
      setStatus(result.body);
    }).catchError((error) {
      setStatus(error);
    });
  }

  @override
  Widget build(BuildContext context) {
    provider = Provider.of<MyProvider>(context);

    ctxt = context;
    return Padding(
      padding: EdgeInsets.all(30),
      child: Column(
        children: <Widget>[
          Expanded(child: Container()),
          Container(
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      border:
                          Border(bottom: BorderSide(color: Colors.grey[200]))),
                  child: TextField(
                    decoration: InputDecoration(
                        errorText: emE,
                        hintText: "Entre email",
                        hintStyle: TextStyle(color: Colors.grey),
                        border: InputBorder.none),
                    onChanged: (value) {
                      email = value;
                    },
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      border:
                          Border(bottom: BorderSide(color: Colors.grey[200]))),
                  child: TextField(
                    decoration: InputDecoration(
                        errorText: pwE,
                        hintText: "Entre mote de passe",
                        hintStyle: TextStyle(color: Colors.grey),
                        border: InputBorder.none),
                    onChanged: (value) {
                      pw = value;
                    },
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(
                "Forgot Password?",
                style: TextStyle(color: Colors.grey),
              ),
              SizedBox(
                width: 15,
              ),
              Flexible(
                child: InkWell(
                    child: Button(),
                    onTap: () {
                      var d = 0;
                      if (pw == null || pw == '') {
                        d = 1;
                        pwE = "Entre mote de passe";
                      }
                      if (email == null || email == '') {
                        d = 1;
                        emE = "Entre Email";
                      }
                      if (d == 0) {
                        login();
                      }
                    }),
              ),
            ],
          ),
          Expanded(child: Container()),
        ],
      ),
    );
  }
}
