import 'dart:convert';
import 'etudiant.dart';

class Services {
  static const String _GET_ETUD = 'GET_ALL';
  static const String _ADD_ETUD_ACTION = 'ADD_ETUD';

  // static Future<List<Etudiant>> getEtudiants() async {
  //   try {
  //     var map = new Map<String, dynamic>();
  //     map["action"] = _GET_ETUD;
  //     final response = await http
  //         .post("http://localhost/al%20cachy/action.php" as Uri, body: map);
  //     print("getEtudiants >> Response:: ${response.body}");
  //     if (response.statusCode == 200) {
  //       List<Etudiant> list = parsePhotos(response.body);
  //       return list;
  //     } else {
  //       return List<Etudiant>();
  //     }
  //   } catch (e) {
  //     return List<Etudiant>();
  //   }
  // }

  static List<Etudiant> parsePhotos(String responseBody) {
    final parsed = json.decode(responseBody).cast<Map<String, dynamic>>();
    return parsed.map<Etudiant>((json) => Etudiant.fromJson(json)).toList();
  }

  // static Future<String> addEmployee(String firstName, String lastName) async {
  //   try {
  //     var map = new Map<String, dynamic>();
  //     map["action"] = _ADD_ETUD_ACTION;
  //     map["first_name"] = firstName;
  //     map["last_name"] = lastName;
  //     final response = await http
  //         .post("http://localhost/al%20cachy/action.php" as Uri, body: map);
  //     print("addEmployee >> Response:: ${response.body}");
  //     return response.body;
  //   } catch (e) {
  //     return 'error';
  //   }
  // }
}
