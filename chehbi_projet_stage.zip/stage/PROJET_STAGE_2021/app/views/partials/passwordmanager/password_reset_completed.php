<div class="container">
	<div>
		<h3>Gestionnaire de réinitialisation de mot de passe</h3>
	</div>
	<hr />	
	<div class="alert alert-success animated bounce">
		<i class="fa fa-check-circle"></i> votre mot de passe a été réinitialisé
	</div>
	<hr />
	<a href="<?php print_link("index/login"); ?>" class="btn btn-info">Cliquez ici pour vous identifier</a>
</div>
	