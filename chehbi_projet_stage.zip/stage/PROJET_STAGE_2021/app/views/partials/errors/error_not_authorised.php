<div class="container">
	<div class="col-sm-7 center-block">
		<div class="panel panel-danger text-center panel-body">
			<i class="material-icons mi-xxlg text-danger">block</i><br /><br />
			<h3 class="bold text-danger">You Are Not Authorised to View this Page!</h3>
			<hr />
			<div class="text-muted"><i>Please Meet The System Adminstrator For More Information!</i></div>
			<hr />
			<div class="">
				<a href="<?php print_link(DEFAULT_PAGE); ?>" class="btn btn-primary"><i class="mdi-action-home"></i> Go to Home Page</a>
			</div>
		</div>
	</div>
</div>