import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Login/components/connexion.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Connexion(),
    );
  }
}
